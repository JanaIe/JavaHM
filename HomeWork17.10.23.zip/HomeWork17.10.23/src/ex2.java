import Game.RspGame;

import java.util.Random;
import java.util.Scanner;

public class ex2 {
    public static void main(String[] args) {

        //Напишите консольную игру
        // «Камень, ножницы, бумага». Пользователь вводит свой выбор
        // (в виде строки или числа). Программа случайным образом делает свой выбор и выводит на экран.
        // Далее программа показывает, кто победитель – пользователь или программа.
        Scanner scn = new Scanner(System.in);
        Random rnd = new Random();
        int randomNum = rnd.nextInt(1,4);
        String com = switch (randomNum){
            case 1 -> "PAPER";
            case 2 -> "SCISSORS";
            default -> "ROCK";
        };
        System.out.println("Whrite your option - scissors, rock or paper. " );
        String choise = scn.nextLine().toUpperCase();
        choise = switch (RspGame.valueOf(choise)){
            case SCISSORS -> "SCISSORS";
            case ROCK ->  "ROCK";
            case PAPER -> "PAPER";
        };
        System.out.println("Computer take " + com);
        System.out.println("You take " + choise);

        System.out.println(
                com == choise ? "the winners are both" : ( choise == "SCISSORS" && com == "PAPER" )
                ^ ( choise == "PAPER" && com == "ROCK" )
                ^ ( choise == "ROCK" && com == "SCISSORS" ) ? " You are a winner. " : " You Lose. "

         );



    }
}
