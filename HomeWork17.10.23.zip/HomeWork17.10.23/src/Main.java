

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

//Пользователь вводит, сколько лет он состоит в браке.
// Программа должна вывести, какая годовщина свадьбы будет у пользователя следующей

        System.out.println("Vvvedite skolko let vi sostoiti v brake");
        Scanner scr = new Scanner(System.in);
        int an = scr.nextInt();

        String nameOfAn = switch (an) {
            case 1 -> "PAPPER";
            case 2 -> "COTTON";
            case 3 -> "LEATHER";
            case 4 -> "LEATHER";
            case 5 -> "LINEN";
            case 6 -> "IRON";
            case 7 -> "WOOL";
            case 8 -> "BRONZE";
            case 9 -> "COPPER";
            case 10 -> "TIN_ALIMINIUM";
            case 11 -> "STEEL";
            case 12 -> "SILK";
            case 13 -> "LACE";
            case 14 -> "IVORY";
            case 15 -> "CRYSTAL";
            case 16 -> "SAPPHIRE";
            case 17 -> "ORCHID";
            case 18 -> "QUARTZ";
            case 19 -> "JADE";
            case 20 -> "PORCELAN";
            default -> "Eto uze sliskom";

        };
        System.out.println(nameOfAn);















    }
}