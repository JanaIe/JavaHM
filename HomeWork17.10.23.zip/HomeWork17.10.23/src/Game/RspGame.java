package Game;

public enum RspGame {
    PAPER,
    ROCK,
    SCISSORS
}
