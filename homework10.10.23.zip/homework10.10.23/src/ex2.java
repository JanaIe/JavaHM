import java.util.Scanner;

public class ex2 {

    public static void main(String[] args) {

        //2 Пользователь-продавец вводит суммарную стоимость покупок и сумму денег,
        // которую дал покупатель. Выведите сумму сдачи в виде “X рублей и Y копеек”.


        System.out.println("eingeben summe");
        System.out.println("eingeben bar geld");

        Scanner scn = new Scanner(System.in);

        double summe = scn.nextDouble();
        double barGeld = scn.nextDouble();

        System.out.println((barGeld-summe) + " рублей и "+ (barGeld-summe)/100 +" копеек");


    }
}
