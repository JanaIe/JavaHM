import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        // 1 уровень сложности:
        // 1 Дана длина в метрах.
        // Напишите программу, которая переводит указанное значение в км, мили, футы и аршины.
        // Выведите начальное и конвертированные значения на экран.

        Scanner scn = new Scanner(System.in);
        System.out.println("Eingeben m");
        double m = scn.nextDouble();
        double km = 1000;
        double mile = 1609.34;
        double f = 0.30;
        double a = 0.71;

        System.out.println( m+"meter is "+ m/km + " kilometer");
        System.out.println( m +"meter is "+m/mile + " mile");
        System.out.println( m+ "meter is "+m/f+ " futi");
        System.out.println( m+"meter is " +m/a+ " arsche");


    }
}