import java.util.Scanner;

public class Main {
    public static void main(String[] args) {



        //Создать программу, выводящую на экран ближайшее к 10
        // из двух чисел, записанных в переменные m и n.
        //Числа могут быть, как целочисленные, так и дробные.
           //Например :
           //ввод : m=7, n=11
           //вывод: Число 11 ближе к 10.

        System.out.println("write number m");
        System.out.println("write number n");

        Scanner scr = new Scanner(System.in);
        double m = scr.nextDouble();
        double n = scr.nextDouble();
        double c = 10;

        if (m> c && m<n) {
            System.out.println("closer to 10 is number  " + m);

        };

    }
}