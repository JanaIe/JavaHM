import java.util.Scanner;

public class ex3 {
    public static void main(String[] args) {

         //Элвис Пресли жил с 1935 по 1977 год.
         // в которой пользователь вводит год. Если указанный год меньше 1935,
         // то вывести «Элвис ещё не родился».
         // Если указанный пользователем год с 1935 по 1977 включительно,
         // то вывести «Элвис жив!».
         // Если введённый пользователем год больше 1977,
         // то вывести «Элвис навсегда в наших сердцах!»


        System.out.println("write a year: ");


        Scanner scr = new Scanner(System.in);
        int year = scr.nextInt();
        int Born = 1935;
        int Rip = 1977;
        if (year < Born)
        {
            System.out.println("Элвис ещё не родился");

        }
        if (year> Born && year< Rip){

        System.out.println("Элвис жив");}

        if ( year> Rip)

        {System.out.println("Элвис навсегда в наших сердцах!");}


        }






    }
